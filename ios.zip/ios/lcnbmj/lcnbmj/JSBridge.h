#import <Foundation/NSObject.h>

@interface JSBridge: NSObject
@end

