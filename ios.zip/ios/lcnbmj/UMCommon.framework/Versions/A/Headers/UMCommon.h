//
//  UMCommon.h
//  UMCommon
//
//  Created by San Zhang on 11/2/16.
//  Copyright © 2016 UMeng. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UMCommon.
FOUNDATION_EXPORT double UMCommonVersionNumber;

//! Project version string for UMCommon.
FOUNDATION_EXPORT const unsigned char UMCommonVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UMCommon/PublicHeader.h>

#import <UMCommon/UMConfigure.h>
